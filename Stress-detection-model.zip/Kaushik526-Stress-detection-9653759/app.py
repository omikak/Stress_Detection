import streamlit as st
import numpy as np
import pickle

st.set_page_config(page_title="Stress Detection", page_icon="🧠", layout="wide")

# Load model
@st.cache_resource
def load_model():
    with open('stress_model.pkl', 'rb') as f:
        data = pickle.load(f)
    return data['model'], data['scaler'], data['encoder']

model, scaler, encoder = load_model()

st.title("🧠 Stress Detection System")
st.markdown("---")

# Sidebar presets
with st.sidebar:
    st.subheader("Quick Presets")
    preset = st.selectbox(
        "Select a scenario:",
        ["Custom", "Relaxed", "Stressed", "Amusement"]
    )
    
    if preset == "Relaxed":
        hr_val, eda_val, doom_val, content_val = 62, 0.3, 0.5, "Calming"
    elif preset == "Stressed":
        hr_val, eda_val, doom_val, content_val = 98, 2.8, 8.5, "Stress_Inducing"
    elif preset == "Amusement":
        hr_val, eda_val, doom_val, content_val = 93, 1.2, 3.5, "Neutral"
    else:
        hr_val, eda_val, doom_val, content_val = 75, 1.2, 3.5, "Neutral"

# Main inputs
col1, col2 = st.columns(2)

with col1:
    st.subheader("Physiological Data")
    hr = st.slider("Heart Rate (BPM)", 50, 120, hr_val)
    eda = st.slider("EDA (µS)", 0.0, 3.5, eda_val, 0.1)
    temp = st.slider("Temperature (°C)", 35.5, 37.5, 36.4, 0.1)

with col2:
    st.subheader("Behavioral Data")
    doom = st.slider("Doomscrolling Score", 0.0, 10.0, doom_val, 0.5)
    screen = st.slider("Screen Time (hours)", 0.5, 10.0, 3.0, 0.5)
    content = st.selectbox("Content Preference", ["Calming", "Neutral", "Stress_Inducing"], 
                           index=["Calming", "Neutral", "Stress_Inducing"].index(content_val))

# Fixed values for other features
other_features = [5, 50, 0.2, 3, 0.13, 0, 0.4, 0.18, 0.9, 0.3, 35, 0.2, 4, 20, 30, 15]

# Predict button
if st.button("Predict", type="primary", use_container_width=True):
    # Create input
    input_data = np.array([[
        hr, 5, 50, eda, 0.2, 3,
        temp, 0.13, 0, 0.4, 0.18, 0.9,
        screen, 0.3, 35, 0.2, doom,
        4, 20, 30, 15,
        1 if content == "Calming" else 0,
        1 if content == "Neutral" else 0,
        1 if content == "Stress_Inducing" else 0
    ]])
    
    input_scaled = scaler.transform(input_data)
    pred = model.predict(input_scaled)[0]
    probs = model.predict_proba(input_scaled)[0]
    
    # Results
    labels = {0: "LOW STRESS 😊", 1: "HIGH STRESS 😰", 2: "AMUSEMENT 🎉"}
    colors = {0: "green", 1: "red", 2: "blue"}
    
    st.markdown(f"## Result: :{colors[pred]}[{labels[pred]}]")
    st.markdown(f"**Confidence:** {probs[pred]*100:.1f}%")
    
    # Show all probabilities
    st.write("---")
    st.write("### Confidence Breakdown")
    st.write(f"- Low Stress: {probs[0]*100:.1f}%")
    st.write(f"- High Stress: {probs[1]*100:.1f}%")
    st.write(f"- Amusement: {probs[2]*100:.1f}%")

st.markdown("---")
st.caption("Adjust the sliders and click Predict to see results")